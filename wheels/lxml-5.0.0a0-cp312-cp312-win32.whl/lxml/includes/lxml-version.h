#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "5.0.0.alpha0"
#endif
